

/* 

    SPECIAL Book: This allows the user to input stat points based on their SPECIAL Attributes (Strength, Perception, Endurance, Intelligence, Agility, and Luck).
    They will have 28 points to use for distributing the stats. They can not go under 1 point or over 10 points in each stat. They will also be given a perk to 
    go along with that stat amount is in that stat aswell as a description of that stat based on the amount. Once they have inputted their points in the stats,
    then they will be given their results. If they go over 28 points then a message will be displayed. Enjoy!

*/

//! GLOBAL VARIABLES
const newLine = '\n';



// Arrays

//* Perks
const strengthPerks = ['Iron Fist', 'Big Leagues', 'Armorer', 'Blacksmith', 'Heavy Gunner', 'Strong Back', 'Steady Aim', 'Basher', 'Rooted', 'Pain Train'];
const perceptionPerks = ['Pickpocket', 'Rifleman', 'Awareness', 'Locksmith', 'Demolition Expert', 'Night Person', 'Refractor', 'Sniper', 'Penetrator', 'Concentrated Fire'];
const endurancePerks = ['Toughness', 'Lead Belly', 'Life Giver', 'Chem Resistant', 'Aquaboy/Aquagirl', 'Rad Resistant', 'Adamantium Skeleton', 'Cannibal', 'Ghoulish', 'Solar Powered'];
const charismaPerks = ['Cap Collector', 'Lady Killer/Black Widow', 'Lone Wanderer', 'Attack Dog', 'Animal Friend', 'Local Leader', 'Party Boy/Party Girl', 'Inspirational', 'Wasteland Whisperer', 'Intimidation'];
const intelligencePerks = ['V.A.N.S', 'Medic', 'Gun Nut', 'Hacker', 'Scrapper', 'Science', 'Chemist', 'Robotics Expert', 'Nuclear Physicist', 'Nerd Rage'];
const agilityPerks = ['Gunslinger', 'Commando', 'Sneak', 'Mister Sandman', 'Action Boy/Action Girl', 'Moving Target', 'Ninja', 'Quick Hands', 'Blitz', 'Gun-Fu'];
const luckPerks = ['Fortune Finder', 'Scrounger', 'Bloody Mess', 'Mysterious Stranger', 'Idiot Savant', 'Better Criticals', 'Critical Banker', 'Grim Reaper`s Sprint', 'Four Leaf Clover', 'Ricochet'];

//* Stat Desc.
const strengthStatDesc = ['Wet Noodle', 'Beached Jellyfish', 'Doughy Baby', 'Lightweight', 'Average Joe', 'Barrel Chested', 'Beach Bully', 'Circus Strongman', 'Doomsday Pecs', 'Hercule`s Bigger Cousin'];
const perceptionStatDesc = ['Deaf Bat', 'Senile Mole', 'Squinting Newt', 'Unsuspecting Trout', 'Wary Trout', 'Alert Coyote', 'Big-eyed Tiger', 'Monocled Falcon', 'Sniper Hawk', 'Sniper Hawk'];
const enduranceStatDesc = ['Basically Dead', 'Crumbly', 'Do Not Bend', 'Handle with Care', 'Stain-resistant', 'Hardy', 'Tough-as-nails', 'Flame Retardant', 'Bulletproof', 'Unstoppable'];
// const charismaPerkDesc = ['Misanthrope', 'Old Hermit', 'Creepy Undertaker', 'Peevish Librarian', 'Substitute Teacher', 'Cheery Salesman', 'Diplomat', 'Movie Star', 'Casanova', 'Cult Leader'];



// Objects

//! Perk Book (Lists all 70 Perks )
//* Remove comment lines to display perks

// const specialBook = {
//     strength: strengthPerks.forEach(function (perk, stat) {
//         const num = stat + 1;
//          console.log(`S = ${num}  ${perk}`); 
//     }),
//     perception: perceptionPerks.forEach(function (perk, stat) {
//         const num = stat + 1;
//          console.log(`P = ${num}  ${perk}`); 
//     }),
//     endurance: endurancePerks.forEach(function (perk, stat) {
//         const num = stat + 1;
//          console.log(`E = ${num}  ${perk}`); 
//     }),
//     charisma: charismaPerks.forEach(function (perk, stat) {
//         const num = stat + 1;
//          console.log(`C = ${num}  ${perk}`); 
//     }),
//     intelligence: intelligencePerks.forEach(function (perk, stat) {
//         const num = stat + 1;
//          console.log(`I = ${num}  ${perk}`); 
//     }),
//     agility: agilityPerks.forEach(function (perk, stat) {
//         const num = stat + 1;
//          console.log(`A = ${num}  ${perk}`); 
//     }),
//     luck: luckPerks.forEach(function (perk, stat) {
//         const num = stat + 1;
//          console.log(`L = ${num}  ${perk}`); 
//     })
// }


//! Perk and Desc. Decider



const perkDescDecider = {
    strength: function strengthDecider(stat) {
        if (stat < 1) {
            return `You cannot have a SPECIAL Stat be < 1.`;
        } else if (stat === 1) {
            return `S = ${stat} | Perk: ${strengthPerks[0]} | Stat Desc: ${strengthStatDesc[0]}`;
        } else if (stat === 2){
            return `S = ${stat} | Perks: ${strengthPerks[0]} , ${strengthPerks[1]} | Stat Desc: ${strengthStatDesc[1]}`;
        } else if (stat === 3){
            return `S = ${stat} | Perks: ${strengthPerks[0]} , ${strengthPerks[1]} , ${strengthPerks[2]}| Stat Desc: ${strengthStatDesc[2]}`;
        } else if (stat === 4){
            return `S = ${stat} | Perks: ${strengthPerks[0]} , ${strengthPerks[1]} , ${strengthPerks[2]} , ${strengthPerks[3]} | Stat Desc: ${strengthStatDesc[3]}`;
        } else if (stat === 5){
            return `S = ${stat} | Perk: ${strengthPerks[0]} , ${strengthPerks[1]} , ${strengthPerks[2]} , ${strengthPerks[3]} , ${strengthPerks[4]} | Stat Desc: ${strengthStatDesc[4]}`;
        } else if (stat === 6){
            return `S = ${stat} | Perk: ${strengthPerks[0]} , ${strengthPerks[1]} , ${strengthPerks[2]} , ${strengthPerks[3]} , ${strengthPerks[4]} , ${strengthPerks[5]} | Stat Desc: ${strengthStatDesc[5]}`;
        } else if (stat === 7){
            return `S = ${stat} | Perk: ${strengthPerks[0]} , ${strengthPerks[1]} , ${strengthPerks[2]} , ${strengthPerks[3]} , ${strengthPerks[4]} , ${strengthPerks[5]} , ${strengthPerks[6]} | Stat Desc: ${strengthStatDesc[6]}`;
        } else if (stat === 8){
            return `S = ${stat} | Perk: ${strengthPerks[0]} , ${strengthPerks[1]} , ${strengthPerks[2]} , ${strengthPerks[3]} , ${strengthPerks[4]} , ${strengthPerks[5]} , ${strengthPerks[6]} , ${strengthPerks[7]} | Stat Desc: ${strengthStatDesc[7]}`;
        } else if (stat === 9){
            return `S = ${stat} | Perk: ${strengthPerks[0]} , ${strengthPerks[1]} , ${strengthPerks[2]} , ${strengthPerks[3]} , ${strengthPerks[4]} , ${strengthPerks[5]} , ${strengthPerks[6]} , ${strengthPerks[7]} , ${strengthPerks[8]} | Stat Desc: ${strengthStatDesc[8]}`;
        } else if (stat === 10){
            return `S = ${stat} | Perk: ${strengthPerks[0]} , ${strengthPerks[1]} , ${strengthPerks[2]} , ${strengthPerks[3]} , ${strengthPerks[4]} , ${strengthPerks[5]} , ${strengthPerks[6]} , ${strengthPerks[7]} , ${strengthPerks[8]} , ${strengthPerks[9]} | Stat Desc: ${strengthStatDesc[9]}`;
        } else {
            return `You cannot have a SPECIAL Stat be > 10.`;
        }
    },
    perception: function perceptionDecider(stat) {
        if (stat < 1) {
            return `You cannot have a SPECIAL Stat be < 1.`;
        } else if (stat === 1) {
            return `P = ${stat} | Perk: ${perceptionPerks[0]} | Stat Desc: ${perceptionStatDesc[0]}`;
        } else if (stat === 2){
            return `P = ${stat} | Perks: ${perceptionPerks[0]} , ${perceptionPerks[1]} | Stat Desc: ${perceptionStatDesc[1]}`;
        } else if (stat === 3){
            return `P = ${stat} | Perks: ${perceptionPerks[0]} , ${perceptionPerks[1]} , ${perceptionPerks[2]}| Stat Desc: ${perceptionStatDesc[2]}`;
        } else if (stat === 4){
            return `P = ${stat} | Perks: ${perceptionPerks[0]} , ${perceptionPerks[1]} , ${perceptionPerks[2]} , ${perceptionPerks[3]} | Stat Desc: ${perceptionStatDesc[3]}`;
        } else if (stat === 5){
            return `P = ${stat} | Perk: ${perceptionPerks[0]} , ${perceptionPerks[1]} , ${perceptionPerks[2]} , ${perceptionPerks[3]} , ${perceptionPerks[4]} | Stat Desc: ${perceptionStatDesc[4]}`;
        } else if (stat === 6){
            return `P = ${stat} | Perk: ${perceptionPerks[0]} , ${perceptionPerks[1]} , ${perceptionPerks[2]} , ${perceptionPerks[3]} , ${perceptionPerks[4]} , ${perceptionPerks[5]} | Stat Desc: ${perceptionStatDesc[5]}`;
        } else if (stat === 7){
            return `P = ${stat} | Perk: ${perceptionPerks[0]} , ${perceptionPerks[1]} , ${perceptionPerks[2]} , ${perceptionPerks[3]} , ${perceptionPerks[4]} , ${perceptionPerks[5]} , ${perceptionPerks[6]} | Stat Desc: ${perceptionStatDesc[6]}`;
        } else if (stat === 8){
            return `P = ${stat} | Perk: ${perceptionPerks[0]} , ${perceptionPerks[1]} , ${perceptionPerks[2]} , ${perceptionPerks[3]} , ${perceptionPerks[4]} , ${perceptionPerks[5]} , ${perceptionPerks[6]} , ${perceptionPerks[7]} | Stat Desc: ${perceptionStatDesc[7]}`;
        } else if (stat === 9){
            return `P = ${stat} | Perk: ${perceptionPerks[0]} , ${perceptionPerks[1]} , ${perceptionPerks[2]} , ${perceptionPerks[3]} , ${perceptionPerks[4]} , ${perceptionPerks[5]} , ${perceptionPerks[6]} , ${perceptionPerks[7]} , ${perceptionPerks[8]} | Stat Desc: ${perceptionStatDesc[8]}`;
        } else if (stat === 10){
            return `P = ${stat} | Perk: ${perceptionPerks[0]} , ${perceptionPerks[1]} , ${perceptionPerks[2]} , ${perceptionPerks[3]} , ${perceptionPerks[4]} , ${perceptionPerks[5]} , ${perceptionPerks[6]} , ${perceptionPerks[7]} , ${perceptionPerks[8]} , ${perceptionPerks[9]} | Stat Desc: ${perceptionStatDesc[9]}`;
        } else {
            return `You cannot have a SPECIAL Stat be > 10.`;
        }
    },
    endurance: function enduranceDecider(stat) {
        if (stat < 1) {
            return `You cannot have a SPECIAL Stat be < 1.`;
        } else if (stat === 1) {
            return `E = ${stat} | Perk: ${endurancePerks[0]} | Stat Desc: ${enduranceStatDesc[0]}`;
        } else if (stat === 2){
            return `E = ${stat} | Perks: ${endurancePerks[0]} , ${endurancePerks[1]} | Stat Desc: ${enduranceStatDesc[1]}`;
        } else if (stat === 3){
            return `E = ${stat} | Perks: ${endurancePerks[0]} , ${endurancePerks[1]} , ${endurancePerks[2]}| Stat Desc: ${enduranceStatDesc[2]}`;
        } else if (stat === 4){
            return `E = ${stat} | Perks: ${endurancePerks[0]} , ${endurancePerks[1]} , ${endurancePerks[2]} , ${endurancePerks[3]} | Stat Desc: ${enduranceStatDesc[3]}`;
        } else if (stat === 5){
            return `E = ${stat} | Perk: ${endurancePerks[0]} , ${endurancePerks[1]} , ${endurancePerks[2]} , ${endurancePerks[3]} , ${endurancePerks[4]} | Stat Desc: ${enduranceStatDesc[4]}`;
        } else if (stat === 6){
            return `E = ${stat} | Perk: ${endurancePerks[0]} , ${endurancePerks[1]} , ${endurancePerks[2]} , ${endurancePerks[3]} , ${endurancePerks[4]} , ${endurancePerks[5]} | Stat Desc: ${enduranceStatDesc[5]}`;
        } else if (stat === 7){
            return `E = ${stat} | Perk: ${endurancePerks[0]} , ${endurancePerks[1]} , ${endurancePerks[2]} , ${endurancePerks[3]} , ${endurancePerks[4]} , ${endurancePerks[5]} , ${endurancePerks[6]} | Stat Desc: ${enduranceStatDesc[6]}`;
        } else if (stat === 8){
            return `E = ${stat} | Perk: ${endurancePerks[0]} , ${endurancePerks[1]} , ${endurancePerks[2]} , ${endurancePerks[3]} , ${endurancePerks[4]} , ${endurancePerks[5]} , ${endurancePerks[6]} , ${endurancePerks[7]} | Stat Desc: ${enduranceStatDesc[7]}`;
        } else if (stat === 9){
            return `E = ${stat} | Perk: ${endurancePerks[0]} , ${endurancePerks[1]} , ${endurancePerks[2]} , ${endurancePerks[3]} , ${endurancePerks[4]} , ${endurancePerks[5]} , ${endurancePerks[6]} , ${endurancePerks[7]} , ${endurancePerks[8]} | Stat Desc: ${enduranceStatDesc[8]}`;
        } else if (stat === 10){
            return `E = ${stat} | Perk: ${endurancePerks[0]} , ${endurancePerks[1]} , ${endurancePerks[2]} , ${endurancePerks[3]} , ${endurancePerks[4]} , ${endurancePerks[5]} , ${endurancePerks[6]} , ${endurancePerks[7]} , ${endurancePerks[8]} , ${endurancePerks[9]} | Stat Desc: ${enduranceStatDesc[9]}`;
        } else {
            return `You cannot have a SPECIAL Stat be > 10.`;
        }
    }
}


//! After Initailized Variables 
const totalPerks = strengthPerks.length + perceptionPerks.length + endurancePerks.length + charismaPerks.length + intelligencePerks.length + agilityPerks.length + luckPerks.length;


//! Input and Output
console.log(newLine);
console.log(`--------- YOUR SPECIAL BOOK ---------`);
 // Input the amount where the # is.

const strengthOP = perkDescDecider.strength(10);
const perceptionOP = perkDescDecider.perception(10);
const enduranceOP = perkDescDecider.endurance(10);
console.log(strengthOP);
console.log(perceptionOP);
console.log(enduranceOP);
