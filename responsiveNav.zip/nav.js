
const mobileNavWrapper = document.getElementById('mobile-nav-wrapper');

const mobileNav = document.getElementById('mobileNav');

const mobileLogo = document.getElementById('mobileLogo');

const mobileToggle = document.getElementById('mobileNavToggle');
const mobileCloser = document.getElementById('mobileNavCloser');

const productsToggle = document.getElementById('productsToggle');
const productsCloser = document.getElementById('productsCloser');

const productsLinks = document.getElementById('mobileProducts');

const supportToggle = document.getElementById('supportToggle');
const supportCloser = document.getElementById('supportCloser');

const supportLinks = document.getElementById('mobileSupport');




function closeLinks() {

    supportLinks.style.display = 'none';

    productsLinks.style.display = 'none';

    supportToggle.style.display = 'block';

    supportCloser.style.display = 'none';

    productsToggle.style.display = 'block';

    productsCloser.style.display = 'none';

}



// Toggle and Close Nav

mobileToggle.addEventListener('click', ()=> {

    mobileNav.style.display = 'block';

    mobileToggle.style.display = 'none';

    mobileCloser.style.display = 'block';

    mobileLogo.style.display = 'none';

    document.body.style.overflow = 'hidden';

});

mobileCloser.addEventListener('click', ()=> {

    mobileNav.style.display = 'none';

    mobileToggle.style.display = 'block';

    mobileCloser.style.display = 'none';

    mobileLogo.style.display = 'flex';

    document.body.style.overflow = 'auto';

    closeLinks();

});



// Products Toggle and Close

productsToggle.addEventListener('click', ()=> {

    productsToggle.style.display = 'none';

    productsCloser.style.display = 'block';

    productsLinks.style.display = 'grid';

});

productsCloser.addEventListener('click', ()=> {

    productsToggle.style.display = 'block';

    productsCloser.style.display = 'none';

    productsLinks.style.display = 'none';

});



// Support Toggle and Close 

supportToggle.addEventListener('click', ()=> {

    supportToggle.style.display = 'none';

    supportCloser.style.display = 'block';

    supportLinks.style.display = 'grid';

});

supportCloser.addEventListener('click', ()=> {

    supportToggle.style.display = 'block';

    supportCloser.style.display = 'none';

    supportLinks.style.display = 'none';

});



//! Bug Fix: Fixes overflow issue when changing screen sizes while mobilenav is opened

autoCloser();

window.onresize = function() {

    autoCloser();

}


function autoCloser() {

    if (window.innerWidth < 900) {

        mobileLogo.style.display = 'flex'

        mobileToggle.style.display = 'block';

        mobileCloser.style.display = 'block';

        mobileNav.style.display = 'none';

        document.body.style.overflow = 'auto';

    } else if (window.innerWidth > 900) {

        document.body.style.overflow = 'auto';

    } else {

        document.body.style.overflow = 'hidden';

    }

}

