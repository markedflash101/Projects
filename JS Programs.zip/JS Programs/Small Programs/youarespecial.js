
/* 

    This program will allow the user to distribute 28 points into their SPECIAL Stats. They cannot 
    go over 10 points in any of the stats nor can they go under 1 point in each stat. Once the 
    user has decided what points go into where they input them. Then their results will be 
    sent to the output along with the perks they can accquire. Enjoy!

*/

const newLine = '\n';

//! Perks and Stat Level Desc.

// Perks
const strengthPerks = ['Iron Fist', 'Big Leagues', 'Armorer', 'Blacksmith', 'Heavy Gunner', 'Strong Back', 'Steady Aim', 'Basher', 'Rooted', 'Pain Train'];
const perceptionPerks = ['Pickpocket', 'Rifleman', 'Awareness', 'Locksmith', 'Demolition Expert', 'Night Person', 'Refractor', 'Sniper', 'Penetrator', 'Concentrated Fire'];
const endurancePerks = ['Toughness', 'Lead Belly', 'Life Giver', 'Chem Resistant', 'Aquaboy/Aquagirl', 'Rad Resistant', 'Adamantium Skeleton', 'Cannibal', 'Ghoulish', 'Solar Powered'];
const charismaPerks = ['Cap Collector', 'Lady Killer/Black Widow', 'Lone Wanderer', 'Attack Dog', 'Animal Friend', 'Local Leader', 'Party Boy/Party Girl', 'Inspirational', 'Wasteland Whisperer', 'Intimidation'];
const totalPerks = strengthPerks.length + perceptionPerks.length + endurancePerks.length; // + charismaPerks.length + intelligencePerks.length + agilityPerks.length + luckPerks.length;

// Perk Desc.
const strengthPerkDesc = ['Wet Noodle', 'Beached Jellyfish', 'Doughy Baby', 'Lightweight', 'Average Joe', 'Barrel Chested', 'Beach Bully', 'Circus Strongman', 'Doomsday Pecs', 'Hercule`s Bigger Cousin'];
const perceptionPerkDesc = ['Deaf Bat', 'Senile Mole', 'Squinting Newt', 'Unsuspecting Trout', 'Wary Trout', 'Alert Coyote', 'Big-eyed Tiger', 'Monocled Falcon', 'Sniper Hawk', 'Sniper Hawk'];
const endurancePerkDesc = ['Basically Dead', 'Crumbly', 'Do Not Bend', 'Handle with Care', 'Stain-resistant', 'Hardy', 'Tough-as-nails', 'Flame Retardant', 'Bulletproof', 'Unstoppable'];
const charismaPerkDesc = ['Misanthrope', 'Old Hermit', 'Creepy Undertaker', 'Peevish Librarian', 'Substitute Teacher', 'Cheery Salesman', 'Diplomat', 'Movie Star', 'Casanova', 'Cult Leader'];


//! SPECIALBOOK Function
const SPECIALBOOK = {

    //** STRENGTH
    strength: function strengthFunction(stat) {
        if (stat < 1) {
            return `SPECIAL Stats cannot be < 1 per stat.`;
        } else if (stat === 1) {
            return `S = ${stat} | Perk: (${strengthPerks[0]}). | You are a ${strengthPerkDesc[0]}`;
        } else if (stat === 2) {
            return `S = ${stat} | Perks: (${strengthPerks[0]}, ${strengthPerks[1]}). | You are a ${strengthPerkDesc[1]}`;
        } else if (stat === 3) {
            return `S = ${stat} | Perks: (${strengthPerks[0]}, ${strengthPerks[1]}, ${strengthPerks[2]}). | You are a ${strengthPerkDesc[2]}`;
        } else if (stat === 4) {
            return `S = ${stat} | Perks: (${strengthPerks[0]}, ${strengthPerks[1]}, ${strengthPerks[2]}, ${strengthPerks[3]}). | You are a ${strengthPerkDesc[3]}`;
        } else if (stat === 5) {
            return `S = ${stat} | Perks: (${strengthPerks[0]}, ${strengthPerks[1]}, ${strengthPerks[2]}, ${strengthPerks[3]}, ${strengthPerks[4]}). | You are a ${strengthPerkDesc[4]}`;
        } else if (stat === 6) {
            return `S = ${stat} | Perks: (${strengthPerks[0]}, ${strengthPerks[1]}, ${strengthPerks[2]}, ${strengthPerks[3]}, ${strengthPerks[4]}, ${strengthPerks[5]}). | You are a ${strengthPerkDesc[5]}`;
        } else if (stat === 7) {
            return `S = ${stat} | Perks: (${strengthPerks[0]}, ${strengthPerks[1]}, ${strengthPerks[2]}, ${strengthPerks[3]}, ${strengthPerks[4]}, ${strengthPerks[5]}, ${strengthPerks[6]}). | You are a ${strengthPerkDesc[6]}`;
        } else if (stat === 8) {
            return `S = ${stat} | Perks: (${strengthPerks[0]}, ${strengthPerks[1]}, ${strengthPerks[2]}, ${strengthPerks[3]}, ${strengthPerks[4]}, ${strengthPerks[5]}, ${strengthPerks[6]}, ${strengthPerks[7]}). | You are a ${strengthPerkDesc[7]}`;
        } else if (stat === 9) {
            return `S = ${stat} | Perks: (${strengthPerks[0]}, ${strengthPerks[1]}, ${strengthPerks[2]}, ${strengthPerks[3]}, ${strengthPerks[4]}, ${strengthPerks[5]}, ${strengthPerks[6]}, ${strengthPerks[7]}, ${strengthPerks[8]}). | You are a ${strengthPerkDesc[8]}`;
        } else if (stat === 10) {
            return `S = ${stat} | Perks: (${strengthPerks[0]}, ${strengthPerks[1]}, ${strengthPerks[2]}, ${strengthPerks[3]}, ${strengthPerks[4]}, ${strengthPerks[5]}, ${strengthPerks[6]}, ${strengthPerks[7]}, ${strengthPerks[8]}, ${strengthPerks[9]}). | You are a ${strengthPerkDesc[9]}`;
        } else {
            return `SPECIAL Stats cannot be > 10 per stat.`
        }
    }, 

    //** PERCEPTION
    perception: function perceptionFunction(stat) {
        if (stat < 1) {
            return `SPECIAL Stats cannot be < 1 per stat.`;
        } else if (stat === 1) {
            return `P = ${stat} | Perk: (${perceptionPerks[0]}). | You are a ${perceptionPerkDesc[0]}`;
        } else if (stat === 2) {
            return `P = ${stat} | Perks: (${perceptionPerks[0]}, ${perceptionPerks[1]}). | You are a ${perceptionPerkDesc[1]}`;
        } else if (stat === 3) {
            return `P = ${stat} | Perks: (${perceptionPerks[0]}, ${perceptionPerks[1]}, ${perceptionPerks[2]}). | You are a ${perceptionPerkDesc[2]}`;
        } else if (stat === 4) {
            return `P = ${stat} | Perks: (${perceptionPerks[0]}, ${perceptionPerks[1]}, ${perceptionPerks[2]}, ${perceptionPerks[3]}). | You are a ${perceptionPerkDesc[3]}`;
        } else if (stat === 5) {
            return `P = ${stat} | Perks: (${perceptionPerks[0]}, ${perceptionPerks[1]}, ${perceptionPerks[2]}, ${perceptionPerks[3]}, ${perceptionPerks[4]}). | You are a ${perceptionPerkDesc[4]}`;
        } else if (stat === 6) {
            return `P = ${stat} | Perks: (${perceptionPerks[0]}, ${perceptionPerks[1]}, ${perceptionPerks[2]}, ${perceptionPerks[3]}, ${perceptionPerks[4]}, ${perceptionPerks[5]}). | You are a ${perceptionPerkDesc[5]}`;
        } else if (stat === 7) {
            return `P = ${stat} | Perks: (${perceptionPerks[0]}, ${perceptionPerks[1]}, ${perceptionPerks[2]}, ${perceptionPerks[3]}, ${perceptionPerks[4]}, ${perceptionPerks[5]}, ${perceptionPerks[6]}). | You are a ${perceptionPerkDesc[6]}`;
        } else if (stat === 8) {
            return `P = ${stat} | Perks: (${perceptionPerks[0]}, ${perceptionPerks[1]}, ${perceptionPerks[2]}, ${perceptionPerks[3]}, ${perceptionPerks[4]}, ${perceptionPerks[5]}, ${perceptionPerks[6]}, ${perceptionPerks[7]}). | You are a ${perceptionPerkDesc[7]}`;
        } else if (stat === 9) {
            return `P = ${stat} | Perks: (${perceptionPerks[0]}, ${perceptionPerks[1]}, ${perceptionPerks[2]}, ${perceptionPerks[3]}, ${perceptionPerks[4]}, ${perceptionPerks[5]}, ${perceptionPerks[6]}, ${perceptionPerks[7]}, ${perceptionPerks[8]}). | You are a ${perceptionPerkDesc[8]}`;
        } else if (stat === 10) {
            return `P = ${stat} | Perks: (${perceptionPerks[0]}, ${perceptionPerks[1]}, ${perceptionPerks[2]}, ${perceptionPerks[3]}, ${perceptionPerks[4]}, ${perceptionPerks[5]}, ${perceptionPerks[6]}, ${perceptionPerks[7]}, ${perceptionPerks[8]}, ${perceptionPerks[9]}). | You are a ${perceptionPerkDesc[9]}`;
        } else {
            return `SPECIAL Stats cannot be > 10 per stat.`
        }
    },

    //** ENDURANCE
    endurance: function enduranceFunction(stat) {
        if (stat < 1) {
            return `SPECIAL Stats cannot be < 1 per stat.`;
        } else if (stat === 1) {
            return `E = ${stat} | Perk: (${endurancePerks[0]}). | You are a ${endurancePerkDesc[0]}`;
        } else if (stat === 2) {
            return `E = ${stat} | Perks: (${endurancePerks[0]}, ${endurancePerks[1]}). | You are a ${endurancePerkDesc[1]}`;
        } else if (stat === 3) {
            return `E = ${stat} | Perks: (${endurancePerks[0]}, ${endurancePerks[1]}, ${endurancePerks[2]}). | You are a ${endurancePerkDesc[2]}`;
        } else if (stat === 4) {
            return `E = ${stat} | Perks: (${endurancePerks[0]}, ${endurancePerks[1]}, ${endurancePerks[2]}, ${endurancePerks[3]}). | You are a ${endurancePerkDesc[3]}`;
        } else if (stat === 5) {
            return `E = ${stat} | Perks: (${endurancePerks[0]}, ${endurancePerks[1]}, ${endurancePerks[2]}, ${endurancePerks[3]}, ${endurancePerks[4]}). | You are a ${endurancePerkDesc[4]}`;
        } else if (stat === 6) {
            return `E = ${stat} | Perks: (${endurancePerks[0]}, ${endurancePerks[1]}, ${endurancePerks[2]}, ${endurancePerks[3]}, ${endurancePerks[4]}, ${endurancePerks[5]}). | You are a ${endurancePerkDesc[5]}`;
        } else if (stat === 7) {
            return `E = ${stat} | Perks: (${endurancePerks[0]}, ${endurancePerks[1]}, ${endurancePerks[2]}, ${endurancePerks[3]}, ${endurancePerks[4]}, ${endurancePerks[5]}, ${endurancePerks[6]}). | You are a ${endurancePerkDesc[6]}`;
        } else if (stat === 8) {
            return `E = ${stat} | Perks: (${endurancePerks[0]}, ${endurancePerks[1]}, ${endurancePerks[2]}, ${endurancePerks[3]}, ${endurancePerks[4]}, ${endurancePerks[5]}, ${endurancePerks[6]}, ${endurancePerks[7]}). | You are a ${endurancePerkDesc[7]}`;
        } else if (stat === 9) {
            return `E = ${stat} | Perks: (${endurancePerks[0]}, ${endurancePerks[1]}, ${endurancePerks[2]}, ${endurancePerks[3]}, ${endurancePerks[4]}, ${endurancePerks[5]}, ${endurancePerks[6]}, ${endurancePerks[7]}, ${endurancePerks[8]}). | You are a ${endurancePerkDesc[8]}`;
        } else if (stat === 10) {
            return `E = ${stat} | Perk: (${endurancePerks[0]}, ${endurancePerks[1]}, ${endurancePerks[2]}, ${endurancePerks[3]}, ${endurancePerks[4]}, ${endurancePerks[5]}, ${endurancePerks[6]}, ${endurancePerks[7]}, ${endurancePerks[8]}, ${endurancePerks[9]}). | You are a ${endurancePerkDesc[9]}`;
        } else {
            return `SPECIAL Stats cannot be > 10 per stat.`
        }
    },

    //** CHARISMA
    charisma: function charismaFunction(stat) {
        if (stat < 1) {
            return `SPECIAL Stats cannot be < 1 per stat.`
        } else if (stat === 1) {
            return `C = ${stat} | Perk: (${charismaPerks[0]}). | You are a ${charismaPerkDesc[0]}`;
        } else if (stat === 2) {
            return `C = ${stat} | Perks: (${charismaPerks[0]}, ${charismaPerks[1]}). | You are a ${charismaPerkDesc[1]}`;
        } else if (stat === 3) {
            return `C = ${stat} | Perks: (${charismaPerks[0]}, ${charismaPerks[1]}, ${charismaPerks[2]}). | You are a ${charismaPerkDesc[2]}`;
        } else if (stat === 4) {
            return `C = ${stat} | Perks: (${charismaPerks[0]}, ${charismaPerks[1]}, ${charismaPerks[2]}, ${charismaPerks[3]}). | You are a ${charismaPerkDesc[3]}`;
        } else if (stat === 5) {
            return `C = ${stat} | Perks: (${charismaPerks[0]}, ${charismaPerks[1]}, ${charismaPerks[2]}, ${charismaPerks[3]}, ${charismaPerks[4]}). | You are a ${charismaPerkDesc[4]}`;
        } else if (stat === 6) {
            return `C = ${stat} | Perks: (${charismaPerks[0]}, ${charismaPerks[1]}, ${charismaPerks[2]}, ${charismaPerks[3]}, ${charismaPerks[4]}, ${charismaPerks[5]}). | You are a ${charismaPerkDesc[5]}`;
        } else if (stat === 7) {
            return `C = ${stat} | Perks: (${charismaPerks[0]}, ${charismaPerks[1]}, ${charismaPerks[2]}, ${charismaPerks[3]}, ${charismaPerks[4]}, ${charismaPerks[5]}, ${charismaPerks[6]}). | You are a ${charismaPerkDesc[6]}`;
        } else if (stat === 8) {
            return `C = ${stat} | Perks: (${charismaPerks[0]}, ${charismaPerks[1]}, ${charismaPerks[2]}, ${charismaPerks[3]}, ${charismaPerks[4]}, ${charismaPerks[5]}, ${charismaPerks[6]}, ${charismaPerks[7]}). | You are a ${charismaPerkDesc[7]}`;
        } else if (stat === 9) {
            return `C = ${stat} | Perks: (${charismaPerks[0]}, ${charismaPerks[1]}, ${charismaPerks[2]}, ${charismaPerks[3]}, ${charismaPerks[4]}, ${charismaPerks[5]}, ${charismaPerks[6]}, ${charismaPerks[7]}, ${charismaPerks[8]}). | You are a ${charismaPerkDesc[8]}`;
        } else if (stat === 10) {
            return `C = ${stat} | Perks: (${charismaPerks[0]}, ${charismaPerks[1]}, ${charismaPerks[2]}, ${charismaPerks[3]}, ${charismaPerks[4]}, ${charismaPerks[5]}, ${charismaPerks[6]}, ${charismaPerks[7]}, ${charismaPerks[8]}, ${charismaPerks[9]}). | You are a ${charismaPerkDesc[9]}`;
        } else {
            return `SPECIAL Stats cannot be > 10 per stat.`
        }
    },

    //** INTELLIGENCE

    //** AGILITY

    //** LUCK

} 

//! Input Section
const strengthOutput = (SPECIALBOOK.strength(10));
const perceptionOutput = (SPECIALBOOK.perception(10));
const enduranceOutput = (SPECIALBOOK.endurance(10));
const charismaOutput = (SPECIALBOOK.charisma(10));
// const intelligenceOutput = (SPECIALBOOK.intelligence(4));
// const agilityOutput = (SPECIALBOOK.agility(4));
// const luckOutput = (SPECIALBOOK.luck(4));


//! Output Section

console.log(newLine);
console.log('------------ YOU ARE SPECIAL ---------------');
console.log(newLine);
console.log(strengthOutput);
console.log(newLine);
console.log(perceptionOutput);
console.log(newLine);
console.log(enduranceOutput);
console.log(newLine);
console.log(charismaOutput);
// console.log(intelligenceOutput);
// console.log(agilityOutput);
// console.log(luckOutput);

