



//! Question One
const questionOneView = document.getElementById('view-1'); // Question View Btn
const questionOneHide = document.getElementById('hide-1'); // Question Hide Btn
const questionOneAnswer = document.getElementById('answer-one'); // Question Answer


questionOneView.addEventListener('click', function() { // Question View Btn Action
    questionOneAnswer.style.display = 'block';
    questionOneAnswer.innerHTML = faqArray[0].answer;
    questionOneView.style.display = 'none';
    questionOneHide.style.display = 'block';
})

questionOneHide.addEventListener('click', function() { // Question Hide Btn Action
    questionOneAnswer.style.display = 'none';
    questionOneHide.style.display = 'none';
    questionOneView.style.display = 'block';
})



//! Question Two
const questionTwoView = document.getElementById('view-2');
const questionTwoHide = document.getElementById('hide-2');
const questionTwoAnswer = document.getElementById('answer-two');


questionTwoView.addEventListener('click', function() { 
    questionTwoAnswer.style.display = 'block';
    questionTwoAnswer.innerHTML = faqArray[1].answer;
    questionTwoView.style.display = 'none';
    questionTwoHide.style.display = 'block';
})

questionTwoHide.addEventListener('click', function() { 
    questionTwoAnswer.style.display = 'none';
    questionTwoHide.style.display = 'none';
    questionTwoView.style.display = 'block';
})


document.querySelectorAll('.question-text').forEach(function(question) { // Changes all .question-text css with JS
    question.style.fontFamily = 'Roboto';
    question.style.fontWeight = 'bold';
})

document.querySelectorAll('.drop-down-answer').forEach(function(answer) { // Changes all .drop-down-answer css with JS
    answer.style.borderTop = 'thin solid #101010';
    answer.style.fontFamily = 'Montserrat';
    answer.style.fontWeight = 'bold';
})

