

/* 
        This program will allow the user to decide what 28 stat points will
        go into which of the 7 different SPECIAL Stats. The program will also inform
        the user if they have used up all of the 28 points and will also inform
        the user if one of the Stats is < 1 or > 10. Along with each stat, the user
        will be given all the perks that come with that stat number.
*/


//* Point Variables
let sPoint;
let pPoint;
let ePoint;
let cPoint;
let iPoint;
let aPoint;
let lPoint;
let sPerk;
let pPerk;
let ePerk;
let cPerk;
let iPerk;
let aPerk;
let lPerk;
const totalPoints = 28;


//* Stat Perks
const strengthPerks = ['Iron Fist', 'Big Leagues', 'Armorer', 'Blacksmith', 'Heavy Gunner', 'Strong Back', 'Steady Aim', 'Basher', 'Rooted', 'Pain Train'];
const perceptionPerks = ['Pickpocket', 'Rifleman', 'Awareness', 'Locksmith', 'Demolition Expert', 'Night Person', 'Refractor', 'Sniper', 'Penetrator', 'Concentrated Fire'];
const endurancePerks = ['Toughness', 'Lead Belly', 'Life Giver', 'Chem Resistant', 'Aquaboy/Aquagirl', 'Rad Resistant', 'Adamantium Skeleton', 'Cannibal', 'Ghoulish', 'Solar Powered'];
const charismaPerks = ['Cap Collector', 'Lady Killer/Black Widow', 'Lone Wanderer', 'Attack Dog', 'Animal Friend', 'Local Leader', 'Party Boy/Party Girl', 'Inspirational', 'Wasteland Whisperer', 'Intimidation'];
const intelligencePerks = ['V.A.N.S', 'Medic', 'Gun Nut', 'Hacker', 'Scrapper', 'Science', 'Chemist', 'Robotics Expert', 'Nuclear Physicist', 'Nerd Rage'];
const agilityPerks = ['Gunslinger', 'Commando', 'Sneak', 'Mister Sandman', 'Action Boy/Action Girl', 'Moving Target', 'Ninja', 'Quick Hands', 'Blitz', 'Gun-Fu'];
const luckPerks = ['Fortune Finder', 'Scrounger', 'Bloody Mess', 'Mysterious Stranger', 'Idiot Savant', 'Better Criticals', 'Critical Banker', 'Grim Reapers Sprint', 'Four Leaf Clover', 'Ricochet'];


//* Stat Determination
const strengthDetermine = function(sStat) {
    if (sStat < 1) {
        return `# cannot be < 1!`;
    } else if (sStat > 10) {
        return `# cannot be > 10!`;
    } else if (sStat === 1) {
        sPerk = `${strengthPerks[0]}`;
        sPoint = 1;
        return sPoint;
    } else if (sStat === 2) {
        sPerk = `${strengthPerks[0]} , ${strengthPerks[1]}`;
        sPoint = 2;
        return sPoint;
    } else if (sStat === 3) {
        sPerk = `${strengthPerks[0]} , ${strengthPerks[1]} , ${strengthPerks[2]}`;
        sPoint = 3;
        return sPoint;
    } else if (sStat === 4) {
        sPerk = `${strengthPerks[0]} , ${strengthPerks[1]} , ${strengthPerks[2]} , ${strengthPerks[3]}`;
        sPoint = 4;
        return sPoint;
    } else if (sStat === 5) {
        sPerk = `${strengthPerks[0]} , ${strengthPerks[1]} , ${strengthPerks[2]} , ${strengthPerks[3]} , ${strengthPerks[4]}`;
        sPoint = 5;
        return sPoint;
    } else if (sStat === 6) {
        sPerk = `${strengthPerks[0]} , ${strengthPerks[1]}  , ${strengthPerks[2]} , ${strengthPerks[3]} , ${strengthPerks[4]} , ${strengthPerks[5]}`;
        sPoint = 6;
        return sPoint;
    } else if (sStat === 7) {
        sPerk = `${strengthPerks[0]} , ${strengthPerks[1]}  , ${strengthPerks[2]} , ${strengthPerks[3]} , ${strengthPerks[4]} , ${strengthPerks[5]} , ${strengthPerks[6]}`;
        sPoint = 7;
        return sPoint;
    } else if (sStat === 8) {
        sPerk = `${strengthPerks[0]} , ${strengthPerks[1]}  , ${strengthPerks[2]} , ${strengthPerks[3]} , ${strengthPerks[4]} , ${strengthPerks[5]} , ${strengthPerks[6]} , ${strengthPerks[7]}`;
        sPoint = 8;
        return sPoint;
    } else if (sStat === 9) {
        sPerk = `${strengthPerks[0]} , ${strengthPerks[1]}  , ${strengthPerks[2]} , ${strengthPerks[3]} , ${strengthPerks[4]} , ${strengthPerks[5]} , ${strengthPerks[6]} , ${strengthPerks[7]} , ${strengthPerks[8]}`;
        sPoint = 9;
        return sPoint;
    } else if (sStat === 10) {
        sPerk = `${strengthPerks[0]} , ${strengthPerks[1]}  , ${strengthPerks[2]} , ${strengthPerks[3]} , ${strengthPerks[4]} , ${strengthPerks[5]} , ${strengthPerks[6]} , ${strengthPerks[7]} , ${strengthPerks[8]} , ${strengthPerks[9]}`;
        sPoint = 10;
        return sPoint;
    }
}

const perceptionDetermine = function(pStat) {
    if (pStat < 1) {
        return `# cannot be < 1!`;
    } else if (pStat > 10) {
        return `# cannot be > 10!`;
    } else if (pStat === 1) {
        pPerk = `${perceptionPerks[0]}`;
        pPoint = 1;
        return pPoint;
    } else if (pStat === 2) {
        pPerk = `${perceptionPerks[0]} , ${perceptionPerks[1]}`;
        pPoint = 2;
        return pPoint;
    } else if (pStat === 3) {
        pPerk = `${perceptionPerks[0]} , ${perceptionPerks[1]} , ${perceptionPerks[2]}`;
        pPoint = 3;
        return pPoint;
    } else if (pStat === 4) {
        pPerk = `${perceptionPerks[0]} , ${perceptionPerks[1]} , ${perceptionPerks[2]} , ${perceptionPerks[3]}`;
        pPoint = 4;
        return pPoint;
    } else if (pStat === 5) {
        pPerk = `${perceptionPerks[0]} , ${perceptionPerks[1]} , ${perceptionPerks[2]} , ${perceptionPerks[3]} , ${perceptionPerks[4]}`;
        pPoint = 5;
        return pPoint;
    } else if (pStat === 6) {
        pPerk = `${perceptionPerks[0]} , ${perceptionPerks[1]}  , ${perceptionPerks[2]} , ${perceptionPerks[3]} , ${perceptionPerks[4]} , ${perceptionPerks[5]}`;
        pPoint = 6;
        return pPoint;
    } else if (pStat === 7) {
        pPerk = `${perceptionPerks[0]} , ${perceptionPerks[1]}  , ${perceptionPerks[2]} , ${perceptionPerks[3]} , ${perceptionPerks[4]} , ${perceptionPerks[5]} , ${perceptionPerks[6]}`;
        pPoint = 7;
        return pPoint;
    } else if (pStat === 8) {
        pPerk = `${perceptionPerks[0]} , ${perceptionPerks[1]}  , ${perceptionPerks[2]} , ${perceptionPerks[3]} , ${perceptionPerks[4]} , ${perceptionPerks[5]} , ${perceptionPerks[6]} , ${perceptionPerks[7]}`;
        pPoint = 8;
        return pPoint;
    } else if (pStat === 9) {
        pPerk = `${perceptionPerks[0]} , ${perceptionPerks[1]}  , ${perceptionPerks[2]} , ${perceptionPerks[3]} , ${perceptionPerks[4]} , ${perceptionPerks[5]} , ${perceptionPerks[6]} , ${perceptionPerks[7]} , ${perceptionPerks[8]}`;
        pPoint = 9;
        return pPoint;
    } else if (pStat === 10) {
        pPerk = `${perceptionPerks[0]} , ${perceptionPerks[1]}  , ${perceptionPerks[2]} , ${perceptionPerks[3]} , ${perceptionPerks[4]} , ${perceptionPerks[5]} , ${perceptionPerks[6]} , ${perceptionPerks[7]} , ${perceptionPerks[8]} , ${perceptionPerks[9]}`;
        pPoint = 10;
        return pPoint;
    }
}

const enduranceDetermine = function(eStat) {
    if (eStat < 1) {
        return `# cannot be < 1!`;
    } else if (eStat > 10) {
        return `# cannot be > 10!`;
    } else if (eStat === 1) {
        ePerk = `${endurancePerks[0]}`;
        ePoint = 1;
        return ePoint;
    } else if (eStat === 2) {
        ePerk = `${endurancePerks[0]} , ${endurancePerks[1]}`;
        ePoint = 2;
        return ePoint;
    } else if (eStat === 3) {
        ePerk = `${endurancePerks[0]} , ${endurancePerks[1]} , ${endurancePerks[2]}`;
        ePoint = 3;
        return ePoint;
    } else if (eStat === 4) {
        ePerk = `${endurancePerks[0]} , ${endurancePerks[1]} , ${endurancePerks[2]} , ${endurancePerks[3]}`;
        ePoint = 4;
        return ePoint;
    } else if (eStat === 5) {
        ePerk = `${endurancePerks[0]} , ${endurancePerks[1]} , ${endurancePerks[2]} , ${endurancePerks[3]} , ${endurancePerks[4]}`;
        ePoint = 5;
        return ePoint;
    } else if (eStat === 6) {
        ePerk = `${endurancePerks[0]} , ${endurancePerks[1]}  , ${endurancePerks[2]} , ${endurancePerks[3]} , ${endurancePerks[4]} , ${endurancePerks[5]}`;
        ePoint = 6;
        return ePoint;
    } else if (eStat === 7) {
        ePerk = `${endurancePerks[0]} , ${endurancePerks[1]}  , ${endurancePerks[2]} , ${endurancePerks[3]} , ${endurancePerks[4]} , ${endurancePerks[5]} , ${endurancePerks[6]}`;
        ePoint = 7;
        return ePoint;
    } else if (eStat === 8) {
        ePerk = `${endurancePerks[0]} , ${endurancePerks[1]}  , ${endurancePerks[2]} , ${endurancePerks[3]} , ${endurancePerks[4]} , ${endurancePerks[5]} , ${endurancePerks[6]} , ${endurancePerks[7]}`;
        ePoint = 8;
        return ePoint;
    } else if (eStat === 9) {
        ePerk = `${endurancePerks[0]} , ${endurancePerks[1]}  , ${endurancePerks[2]} , ${endurancePerks[3]} , ${endurancePerks[4]} , ${endurancePerks[5]} , ${endurancePerks[6]} , ${endurancePerks[7]} , ${endurancePerks[8]}`;
        ePoint = 9;
        return ePoint;
    } else if (eStat === 10) {
        ePerk = `${endurancePerks[0]} , ${endurancePerks[1]}  , ${endurancePerks[2]} , ${endurancePerks[3]} , ${endurancePerks[4]} , ${endurancePerks[5]} , ${endurancePerks[6]} , ${endurancePerks[7]} , ${endurancePerks[8]} , ${endurancePerks[9]}`;
        ePoint = 10;
        return ePoint;
    }
}

const charismaDetermine = function(cStat) {
    if (cStat < 1) {
        return `# cannot be < 1!`;
    } else if (cStat > 10) {
        return `# cannot be > 10!`;
    } else if (cStat === 1) {
        cPerk = `${charismaPerks[0]}`;
        cPoint = 1;
        return cPoint;
    } else if (cStat === 2) {
        cPerk = `${charismaPerks[0]} , ${charismaPerks[1]}`;
        cPoint = 2;
        return cPoint;
    } else if (cStat === 3) {
        cPerk = `${charismaPerks[0]} , ${charismaPerks[1]} , ${charismaPerks[2]}`;
        cPoint = 3;
        return cPoint;
    } else if (cStat === 4) {
        cPerk = `${charismaPerks[0]} , ${charismaPerks[1]} , ${charismaPerks[2]} , ${charismaPerks[3]}`;
        cPoint = 4;
        return cPoint;
    } else if (cStat === 5) {
        cPerk = `${charismaPerks[0]} , ${charismaPerks[1]} , ${charismaPerks[2]} , ${charismaPerks[3]} , ${charismaPerks[4]}`;
        cPoint = 5;
        return cPoint;
    } else if (cStat === 6) {
        cPerk = `${charismaPerks[0]} , ${charismaPerks[1]}  , ${charismaPerks[2]} , ${charismaPerks[3]} , ${charismaPerks[4]} , ${charismaPerks[5]}`;
        cPoint = 6;
        return cPoint;
    } else if (cStat === 7) {
        cPerk = `${charismaPerks[0]} , ${charismaPerks[1]}  , ${charismaPerks[2]} , ${charismaPerks[3]} , ${charismaPerks[4]} , ${charismaPerks[5]} , ${charismaPerks[6]}`;
        cPoint = 7;
        return cPoint;
    } else if (cStat === 8) {
        cPerk = `${charismaPerks[0]} , ${charismaPerks[1]}  , ${charismaPerks[2]} , ${charismaPerks[3]} , ${charismaPerks[4]} , ${charismaPerks[5]} , ${charismaPerks[6]} , ${charismaPerks[7]}`;
        cPoint = 8;
        return cPoint;
    } else if (cStat === 9) {
        cPerk = `${charismaPerks[0]} , ${charismaPerks[1]}  , ${charismaPerks[2]} , ${charismaPerks[3]} , ${charismaPerks[4]} , ${charismaPerks[5]} , ${charismaPerks[6]} , ${charismaPerks[7]} , ${charismaPerks[8]}`;
        cPoint = 9;
        return cPoint;
    } else if (cStat === 10) {
        cPerk = `${charismaPerks[0]} , ${charismaPerks[1]}  , ${charismaPerks[2]} , ${charismaPerks[3]} , ${charismaPerks[4]} , ${charismaPerks[5]} , ${charismaPerks[6]} , ${charismaPerks[7]} , ${charismaPerks[8]} , ${charismaPerks[9]}`;
        cPoint = 10;
        return cPoint;
    }
}

const intelligenceDetermine = function(iStat) {
    if (iStat < 1) {
        return `# cannot be < 1!`;
    } else if (iStat > 10) {
        return `# cannot be > 10!`;
    } else if (iStat === 1) {
        iPerk = `${intelligencePerks[0]}`;
        iPoint = 1;
        return iPoint;
    } else if (iStat === 2) {
        iPerk = `${intelligencePerks[0]} , ${intelligencePerks[1]}`;
        iPoint = 2;
        return iPoint;
    } else if (iStat === 3) {
        iPerk = `${intelligencePerks[0]} , ${intelligencePerks[1]} , ${intelligencePerks[2]}`;
        iPoint = 3;
        return iPoint;
    } else if (iStat === 4) {
        iPerk = `${intelligencePerks[0]} , ${intelligencePerks[1]} , ${intelligencePerks[2]} , ${intelligencePerks[3]}`;
        iPoint = 4;
        return iPoint;
    } else if (iStat === 5) {
        iPerk = `${intelligencePerks[0]} , ${intelligencePerks[1]} , ${intelligencePerks[2]} , ${intelligencePerks[3]} , ${intelligencePerks[4]}`;
        iPoint = 5;
        return iPoint;
    } else if (iStat === 6) {
        iPerk = `${intelligencePerks[0]} , ${intelligencePerks[1]}  , ${intelligencePerks[2]} , ${intelligencePerks[3]} , ${intelligencePerks[4]} , ${intelligencePerks[5]}`;
        iPoint = 6;
        return iPoint;
    } else if (iStat === 7) {
        iPerk = `${intelligencePerks[0]} , ${intelligencePerks[1]}  , ${intelligencePerks[2]} , ${intelligencePerks[3]} , ${intelligencePerks[4]} , ${intelligencePerks[5]} , ${intelligencePerks[6]}`;
        iPoint = 7;
        return iPoint;
    } else if (iStat === 8) {
        iPerk = `${intelligencePerks[0]} , ${intelligencePerks[1]}  , ${intelligencePerks[2]} , ${intelligencePerks[3]} , ${intelligencePerks[4]} , ${intelligencePerks[5]} , ${intelligencePerks[6]} , ${intelligencePerks[7]}`;
        iPoint = 8;
        return iPoint;
    } else if (iStat === 9) {
        iPerk = `${intelligencePerks[0]} , ${intelligencePerks[1]}  , ${intelligencePerks[2]} , ${intelligencePerks[3]} , ${intelligencePerks[4]} , ${intelligencePerks[5]} , ${intelligencePerks[6]} , ${intelligencePerks[7]} , ${intelligencePerks[8]}`;
        iPoint = 9;
        return iPoint;
    } else if (iStat === 10) {
        iPerk = `${intelligencePerks[0]} , ${intelligencePerks[1]}  , ${intelligencePerks[2]} , ${intelligencePerks[3]} , ${intelligencePerks[4]} , ${intelligencePerks[5]} , ${intelligencePerks[6]} , ${intelligencePerks[7]} , ${intelligencePerks[8]} , ${intelligencePerks[9]}`;
        iPoint = 10;
        return iPoint;
    }
}

const agilityDetermine = function(aStat) {
    if (aStat < 1) {
        return `# cannot be < 1!`;
    } else if (aStat > 10) {
        return `# cannot be > 10!`;
    } else if (aStat === 1) {
        aPerk = `${agilityPerks[0]}`;
        aPoint = 1;
        return aPoint;
    } else if (aStat === 2) {
        aPerk = `${agilityPerks[0]} , ${agilityPerks[1]}`;
        aPoint = 2;
        return aPoint;
    } else if (aStat === 3) {
        aPerk = `${agilityPerks[0]} , ${agilityPerks[1]} , ${agilityPerks[2]}`;
        aPoint = 3;
        return aPoint;
    } else if (aStat === 4) {
        aPerk = `${agilityPerks[0]} , ${agilityPerks[1]} , ${agilityPerks[2]} , ${agilityPerks[3]}`;
        aPoint = 4;
        return aPoint;
    } else if (aStat === 5) {
        aPerk = `${agilityPerks[0]} , ${agilityPerks[1]} , ${agilityPerks[2]} , ${agilityPerks[3]} , ${agilityPerks[4]}`;
        iPoint = 5;
        return aPoint;
    } else if (aStat === 6) {
        aPerk = `${agilityPerks[0]} , ${agilityPerks[1]}  , ${agilityPerks[2]} , ${agilityPerks[3]} , ${agilityPerks[4]} , ${agilityPerks[5]}`;
        aPoint = 6;
        return aPoint;
    } else if (aStat === 7) {
        aPerk = `${agilityPerks[0]} , ${agilityPerks[1]}  , ${agilityPerks[2]} , ${agilityPerks[3]} , ${agilityPerks[4]} , ${agilityPerks[5]} , ${agilityPerks[6]}`;
        aPoint = 7;
        return aPoint;
    } else if (aStat === 8) {
        aPerk = `${agilityPerks[0]} , ${agilityPerks[1]}  , ${agilityPerks[2]} , ${agilityPerks[3]} , ${agilityPerks[4]} , ${agilityPerks[5]} , ${agilityPerks[6]} , ${agilityPerks[7]}`;
        aPoint = 8;
        return aPoint;
    } else if (aStat === 9) {
        aPerk = `${agilityPerks[0]} , ${agilityPerks[1]}  , ${agilityPerks[2]} , ${agilityPerks[3]} , ${agilityPerks[4]} , ${agilityPerks[5]} , ${agilityPerks[6]} , ${agilityPerks[7]} , ${agilityPerks[8]}`;
        aPoint = 9;
        return aPoint;
    } else if (aStat === 10) {
        aPerk = `${agilityPerks[0]} , ${agilityPerks[1]}  , ${agilityPerks[2]} , ${agilityPerks[3]} , ${agilityPerks[4]} , ${agilityPerks[5]} , ${agilityPerks[6]} , ${agilityPerks[7]} , ${agilityPerks[8]} , ${agilityPerks[9]}`;
        aPoint = 10;
        return aPoint;
    }
} 

const luckDetermine = function(lStat) {
    if (lStat < 1) {
        return `# cannot be < 1!`;
    } else if (lStat > 10) {
        return `# cannot be > 10!`;
    } else if (lStat === 1) {
        lPerk = `${luckPerks[0]}`;
        lPoint = 1;
        return lPoint;
    } else if (lStat === 2) {
        lPerk = `${luckPerks[0]} , ${luckPerks[1]}`;
        lPoint = 2;
        return lPoint;
    } else if (lStat === 3) {
        lPerk = `${luckPerks[0]} , ${luckPerks[1]} , ${luckPerks[2]}`;
        lPoint = 3;
        return lPoint;
    } else if (lStat === 4) {
        lPerk = `${luckPerks[0]} , ${luckPerks[1]} , ${luckPerks[2]} , ${luckPerks[3]}`;
        lPoint = 4;
        return lPoint;
    } else if (lStat === 5) {
        lPerk = `${luckPerks[0]} , ${luckPerks[1]} , ${luckPerks[2]} , ${luckPerks[3]} , ${luckPerks[4]}`;
        lPoint = 5;
        return lPoint;
    } else if (lStat === 6) {
        lPerk = `${luckPerks[0]} , ${luckPerks[1]}  , ${luckPerks[2]} , ${luckPerks[3]} , ${luckPerks[4]} , ${luckPerks[5]}`;
        lPoint = 6;
        return lPoint;
    } else if (lStat === 7) {
        lPerk = `${luckPerks[0]} , ${luckPerks[1]}  , ${luckPerks[2]} , ${luckPerks[3]} , ${luckPerks[4]} , ${luckPerks[5]} , ${luckPerks[6]}`;
        lPoint = 7;
        return lPoint;
    } else if (lStat === 8) {
        lPerk = `${luckPerks[0]} , ${luckPerks[1]}  , ${luckPerks[2]} , ${luckPerks[3]} , ${luckPerks[4]} , ${luckPerks[5]} , ${luckPerks[6]} , ${luckPerks[7]}`;
        lPoint = 8;
        return lPoint;
    } else if (lStat === 9) {
        lPerk = `${luckPerks[0]} , ${luckPerks[1]}  , ${luckPerks[2]} , ${luckPerks[3]} , ${luckPerks[4]} , ${luckPerks[5]} , ${luckPerks[6]} , ${luckPerks[7]} , ${luckPerks[8]}`;
        lPoint = 9;
        return lPoint;
    } else if (lStat === 10) {
        lPerk = `${luckPerks[0]} , ${luckPerks[1]}  , ${luckPerks[2]} , ${luckPerks[3]} , ${luckPerks[4]} , ${luckPerks[5]} , ${luckPerks[6]} , ${luckPerks[7]} , ${luckPerks[8]} , ${luckPerks[9]}`;
        lPoint = 10;
        return lPoint;
    }
} 

console.log('\n');
                                             //!  V---- The (#) are the user inputs.  
const strengthDetermineOutput = strengthDetermine(4);
const perceptionDetermineOutput = perceptionDetermine(4);
const enduranceDetermineOutput = enduranceDetermine(4);
const charismaDetermineOutput = charismaDetermine(4);
const intelligenceDetermineOutput = intelligenceDetermine(4);
const agilityDetermineOutput = agilityDetermine(4);
const luckDetermineOutput = luckDetermine(4);

console.log(`S = ${strengthDetermineOutput} | ${sPerk}`);
console.log(`P = ${perceptionDetermineOutput} | ${pPerk}`);
console.log(`E = ${enduranceDetermineOutput} | ${ePerk}`);
console.log(`C = ${charismaDetermineOutput} | ${cPerk}`);
console.log(`I = ${intelligenceDetermineOutput} | ${iPerk}`);
console.log(`A = ${agilityDetermineOutput} | ${aPerk}`);
console.log(`L = ${luckDetermineOutput} | ${lPerk}`)



//* Adding up the points
const addUp = sPoint + pPoint + ePoint + cPoint + iPoint + aPoint + lPoint;

console.log('\n');

if (addUp === totalPoints) {
    console.log('You have used all of your points!');
} else if (addUp < totalPoints) {
    console.log('You still have some points left!');
    console.log(`You have used ${addUp} points. You have ${28 - addUp} points left!`);
} else {
    console.log('You have used up more than 28 points! Remove some in the stats.');
}

