
//! Add Item Button
const addButton = document.getElementById('add-button');
addButton.addEventListener('click', addToDoItem);
function addToDoItem() {
    alert('Add Button clicked!');
}


//! Clear Item Button
const clearButton = document.getElementById('clear-completed-button');
clearButton.addEventListener('click', clearCompletedToDoItems);
function clearCompletedToDoItems() {
    alert('Clear Button clicked!');
}


//! Empty List Button
const emptyButton = document.getElementById('empty-button');
emptyButton.addEventListener('click', emptyList);
function emptyList() {
    alert('Empty List Button clicked!');
}


//! Save List Button
const saveButton = document.getElementById('save-button');
saveButton.addEventListener('click', saveList);
function saveList() {
    alert('Save list button clicked!');
}


//! Adding List Items
const toDoEntryBox = document.getElementById('todo-entry-box');
const toDoList = document.getElementById('todo-list');