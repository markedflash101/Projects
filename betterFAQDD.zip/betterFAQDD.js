


    //! Question One

    const qOne = document.getElementById('q-one');
    const answerOne = document.getElementById('a-one');
    const viewOne = document.getElementById('view-one');
    const hideOne = document.getElementById('hide-one');


    viewOne.addEventListener('click', function() {

            answerOne.style.display = 'block';
            viewOne.style.display = 'none';
            hideOne.style.display = 'block';
            
    });

    hideOne.addEventListener('click', function() {

            answerOne.style.display = 'none';
            viewOne.style.display = 'block';
            hideOne.style.display = 'none';

    });



    //! Question Two

    const qTwo = document.getElementById('q-two');
    const answerTwo = document.getElementById('a-two');
    const viewTwo = document.getElementById('view-two');
    const hideTwo = document.getElementById('hide-two');

    viewTwo.addEventListener('click', function() {

            answerTwo.style.display = 'block';
            viewTwo.style.display = 'none';
            hideTwo.style.display = 'block';

    });

    hideTwo.addEventListener('click', function() {

            answerTwo.style.display = 'none';
            viewTwo.style.display = 'block';
            hideTwo.style.display = 'none';
            
    });