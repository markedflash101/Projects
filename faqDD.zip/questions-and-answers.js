const faqArray = [{
    question: 'Lorem ipsum dolor sit amet.',
    answer: 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dolorum eveniet vel recusandae sunt. Hic dolor minima, impedit enim unde eaque.'
},
{
    question: 'Lorem sit amet consectetur adipisicing elit.',
    answer: 'Lorem ipsum dolor sit amet.'
}]